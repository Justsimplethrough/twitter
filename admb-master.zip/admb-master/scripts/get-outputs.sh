#!/bin/sh

echo Example:admb:ham4.tpl
cat $1admb/buscycle/ham4.par
cat $1admb/buscycle/ham4.std

echo Example:admb:ham5.tpl
cat $1admb/buscycle/ham5.par
cat $1admb/buscycle/ham5.std

echo Example:admb:catage.tpl
cat $1admb/catage/catage.par
cat $1admb/catage/catage.std

echo Example:admb:chem_eng.tpl
cat $1admb/chem_eng/chem_eng.par
cat $1admb/chem_eng/chem_eng.std

echo Example:admb:finance.tpl
cat $1admb/finance/finance.par
cat $1admb/finance/finance.std

echo Example:admb:forest.tpl
cat $1admb/forest/forest.par
cat $1admb/forest/forest.std

echo Example:admb:pella_t.tpl
cat $1admb/pella_t/pella_t.par
cat $1admb/pella_t/pella_t.std

echo Example:admb:vonb.tpl
cat $1admb/robreg/vonb.par
cat $1admb/robreg/vonb.std

echo Example:admb:vonbr.tpl
cat $1admb/robreg/vonbr.par
cat $1admb/robreg/vonbr.std

echo Example:admb:simple.tpl
cat $1admb/simple/simple.par
cat $1admb/simple/simple.std

echo Example:admb:truncreg.tpl
cat $1admb/truncreg/truncreg.par
cat $1admb/truncreg/truncreg.std

echo Example:admb:n2mvol.tpl
cat $1admb/vol/n2mvol.par
cat $1admb/vol/n2mvol.std

echo Example:admb-re:bcb.tpl
cat $1admb-re/bcb/bcb.par
cat $1admb-re/bcb/bcb.std

echo Example:admb-re:biglog.tpl
cat $1admb-re/biglog/biglog.par
cat $1admb-re/biglog/biglog.std

echo Example:admb-re:bvprobit.tpl
cat $1admb-re/glmmadmb/bvprobit.par
cat $1admb-re/glmmadmb/bvprobit.std

echo Example:admb-re:glmmadmb.tpl
cat $1admb-re/glmmadmb/glmmadmb.par
cat $1admb-re/glmmadmb/glmmadmb.std

echo Example:admb-re:caest.tpl
cat $1admb-re/caest/caest.par
cat $1admb-re/caest/caest.std

echo Example:admb-re:liver_gamma.tpl
cat $1admb-re/gamma/liver_gamma.par
cat $1admb-re/gamma/liver_gamma.std

echo Example:admb-re:kidney.tpl
cat $1admb-re/kidney/kidney.par
cat $1admb-re/kidney/kidney.std

echo Example:admb-re:lidar.tpl
cat $1admb-re/lidar/lidar.par
cat $1admb-re/lidar/lidar.std

echo Example:admb-re:logistic.tpl
cat $1admb-re/logistic/logistic.par
cat $1admb-re/logistic/logistic.std

echo Example:admb-re:nbmm.tpl
cat $1admb-re/nbmm/nbmm.par
cat $1admb-re/nbmm/nbmm.std

echo Example:admb-re:nested4.tpl
cat $1admb-re/nested4/nested4.par
cat $1admb-re/nested4/nested4.std

echo Example:admb-re:orange.tpl
cat $1admb-re/orange/orange.par
cat $1admb-re/orange/orange.std

echo Example:admb-re:orange2.tpl
cat $1admb-re/orange2/orange2.par
cat $1admb-re/orange2/orange2.std

echo Example:admb-re:orange_cor.tpl
cat $1admb-re/orange_cor/orange_cor.par
cat $1admb-re/orange_cor/orange_cor.std

echo Example:admb-re:pheno.tpl
cat $1admb-re/pheno/pheno.par
cat $1admb-re/pheno/pheno.std

echo Example:admb-re:polio.tpl
cat $1admb-re/polio/polio.par
cat $1admb-re/polio/polio.std

echo Example:admb-re:sdv.tpl
cat $1admb-re/sdv/sdv.par
cat $1admb-re/sdv/sdv.std

echo Example:admb-re:diet.tpl
cat $1admb-re/skewed/diet.par
cat $1admb-re/skewed/diet.std

echo Example:admb-re:diet_sk.tpl
cat $1admb-re/skewed/diet_sk.par
cat $1admb-re/skewed/diet_sk.std

echo Example:admb-re:socatt.tpl
cat $1admb-re/socatt/socatt.par
cat $1admb-re/socatt/socatt.std

echo Example:admb-re:spatial.tpl
cat $1admb-re/spatial/spatial.par
cat $1admb-re/spatial/spatial.std

echo Example:admb-re:union.tpl
cat $1admb-re/union/union.par
cat $1admb-re/union/union.std

echo Example:admb-re:binomial.tpl
cat $1admb-re/weights/binomial.par
cat $1admb-re/weights/binomial.std
