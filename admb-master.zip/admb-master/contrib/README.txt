Add function declarations to 'contrib/src/contrib.h' and implementations to 
'contrib/src/contrib.cpp'.  Descriptive documentation should be added.

Rebuild,

   [~/admb-trunk/]$ make

After the build, all functions will be available to be used in the tpl file. 

--------------------------------------------------------------------------------
$ID$
