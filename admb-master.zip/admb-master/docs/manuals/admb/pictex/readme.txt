Currently (22 Sep 2013) there are 7 figures in the ADMB manual that are drawn in
LaTeX using the PicTeX command \beginpicture.

For the purpose of producing an HTML version of the manual, these 7 figures are
made available here as PNG bitmap images:

  biomass-mcmc.png
  biomass-profile.png
  ham.png
  vonb-bad.png
  vonb-good.png
  vonb-robust-bad.png
  vonb-robust-good.png

This does not affect the PDF version of the manual, where the vector images are
produced with PicTeX.
